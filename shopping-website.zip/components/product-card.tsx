"use client"

import Image from "next/image"
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { useToast } from "@/hooks/use-toast"

interface Product {
  id: number
  title: string
  price: number
  description: string
  category: string
  image: string
  rating: {
    rate: number
    count: number
  }
}

interface ProductCardProps {
  product: Product
}

export default function ProductCard({ product }: ProductCardProps) {
  const { toast } = useToast()

  const addToCart = () => {
    toast({
      title: "Added to cart",
      description: `${product.title} has been added to your cart`,
    })
  }

  return (
    <Card className="h-full flex flex-col">
      <CardHeader className="p-4 flex-grow-0">
        <div className="aspect-square relative w-full h-48 bg-gray-100 rounded-md overflow-hidden">
          <Image
            src={product.image || "/placeholder.svg"}
            alt={product.title}
            fill
            sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw"
            style={{ objectFit: "contain" }}
          />
        </div>
      </CardHeader>
      <CardContent className="flex-grow">
        <h3 className="font-medium text-sm line-clamp-2 mb-2">{product.title}</h3>
        <div className="flex justify-between items-center">
          <span className="font-bold">${product.price.toFixed(2)}</span>
          <div className="flex items-center text-sm text-gray-500">
            <span>★ {product.rating.rate}</span>
            <span className="ml-1">({product.rating.count})</span>
          </div>
        </div>
      </CardContent>
      <CardFooter className="pt-0">
        <Button onClick={addToCart} className="w-full">
          Add to Cart
        </Button>
      </CardFooter>
    </Card>
  )
}
